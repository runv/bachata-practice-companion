// src/components/ui/themes/FileInfo.css.ts
import { style } from '@vanilla-extract/css';

export const fileInfo = style({
  fontSize: '0.875rem',
  color: '#555',
  marginTop: '0.25rem',
   /*fontSize: vars.font.size.sm,
  color: vars.color.textSecondary,
  marginTop: vars.space.sm,*/
});


