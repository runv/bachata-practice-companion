// src/hooks/useFileSizeCheck.ts
import { useState } from 'react';

export const useFileSizeCheck = (maxSizeMB = 100) => {
  const [error, setError] = useState<string | null>(null);

  const checkSize = (file: File) => {
    if (file.size > maxSizeMB * 1024 * 1024) {
      setError(`File is too large. Maximum allowed size is ${maxSizeMB} MB.`);
      return false;
    }
    setError(null);
    return true;
  };

  return { checkSize, error };
};
